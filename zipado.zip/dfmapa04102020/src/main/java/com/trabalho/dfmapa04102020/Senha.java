package com.trabalho.dfmapa04102020;

/**
 *
 * @author Daniel F
 */
public class Senha {
    
    private int numero;
    
    private char tipo;

    public Senha(int numero, char tipo) {
        this.numero = numero;
        this.tipo = tipo;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public char getTipo() {
        return tipo;
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }
    
    public String getSenhaTxt() {
        return this.tipo + "-" + this.numero;
    }
    
    
    
    
    
}
